//------------------------------------------------------------------------------
// <copyright file="WebDataService.svc.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
// </copyright>
//------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Data.Services;
using System.Data.Services.Common;
using System.Linq;
using System.ServiceModel.Web;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace WcfService2
{


    public class WcfDataService1 : IService1
    {
        private String username="na";
        private String password="na";

        public void Login(String username, string password)
        {
            SqlConnection Connection = new SqlConnection("Data Source=(LocalDb)\v11.0;AttachDbFilename='C:\\Users\\Brian-Laptop\\Documents\\Visual Studio 2012\\Projects\\WcfService2\\WcfService2\\App_Data\\Database1.mdf';Integrated Security=True");
            SqlCommand Command=new SqlCommand("SELECT * FROM [Users] WHERE Username=@Username AND Password=@Password", Connection);
             Command.Parameters.AddWithValue("@Username", username);
            Command.Parameters.AddWithValue("@Password", password);
            
           Command.CommandType=CommandType.Text;

             Connection.Open();
            Command.Connection = Connection;
            SqlDataReader reader= Command.ExecuteReader();
       
            //if username==database username and password==database password
            if(reader!=null)
            {
                this.username = username;
                this.password = password;
            }
           
          
        }
        public String getUsername()
        {
            return username;
        }
        public String getPassword()
        {
            return password;
        }
    }
}
