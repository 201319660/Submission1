﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;



namespace WcfService2
{
    public partial class Home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            String usernameT = Username.Text.ToString();
            String passwordT= Password.Text.ToString();

            WcfDataService1 service = new WcfDataService1();
            service.Login(usernameT, passwordT);

            if (service.getUsername()!="na")
            {
                Response.Redirect("Page1");
            }
        }
    }
}